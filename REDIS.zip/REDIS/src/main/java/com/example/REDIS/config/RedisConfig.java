package com.example.REDIS.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;

import com.example.REDIS.model.Country;

@Configuration
public class RedisConfig {
	
//	two things are required they are :
//		1) jedis connection factory
//		2) redis template
	
//	jedis connection factory
	
	@Bean
	public JedisConnectionFactory jedisConnectionFactory() {
		JedisConnectionFactory jedis = new JedisConnectionFactory();
//		redis server config
		return jedis;
	}
//	redistemplate
	
	public RedisTemplate<CountryCountry>redisTemplate()
	{
		RedisTemplate<String,Country> redisTemplate=new RedisTemplate<>();
		redisTemplate.setConnectionFactory(jedisConnection());
		return redistemplate;
	}
}
