package com.example.REDIS.service;

import org.springframework.stereotype.Service;

@Service
public class CountryService{
	private HashOperations<String,Object,Object>opsForHash=null;
	
	public CountryService(RedisTemplate<String,Country>redis)
	{
		opsForHash=redis.opsForHash();
	}
	
	public String addCountry(country);
	

}
